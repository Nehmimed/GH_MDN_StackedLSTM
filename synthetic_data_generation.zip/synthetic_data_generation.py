import pandas as pd
import numpy as np
import datetime
from scipy.stats import lognorm, expon 

# --- Configuration ---
N_STATIONS = 1
START_DATE = "2022-01-01"
END_DATE = "2023-12-31"
OUTPUT_CSV = "synthetic_river_wq_hourly_deep_learning.csv"
HOURLY_FREQ = 'h'  

# --- Helper Functions ---

def seasonal_component(time_vector, amplitude, phase_shift_days, period_days=365.25):
    """Generates a seasonal sinusoidal component based on day of year. Returns NumPy array."""
    day_of_year = time_vector.dayofyear.to_numpy()  
    return amplitude * np.cos(2 * np.pi * (day_of_year - phase_shift_days) / period_days)

def diel_component(time_vector, amplitude, peak_hour, trough_hour=None):
    """Generates a diel sinusoidal component. Returns NumPy array.
       If trough_hour is None, assumes a simple sine wave peaking at peak_hour.
       If trough_hour is given, creates a more skewed diel shape.
    """
    hour_of_day = time_vector.hour.to_numpy()  
    if trough_hour is None:
        phase_shift_hours = peak_hour - 6
        return amplitude * np.sin(2 * np.pi * (hour_of_day - phase_shift_hours) / 24)
    else:
         
        effective_hour = hour_of_day.copy()
        
        if peak_hour > trough_hour:  

            mask = hour_of_day < trough_hour
            effective_hour[mask] += 24

        phase_shift_hours = peak_hour - 6 
        return amplitude * np.sin(2 * np.pi * (effective_hour - phase_shift_hours) / 24)


def generate_ar1_noise_multivariate(n_points, phi_vector, innovation_cov_matrix):
    """
    Generates multivariate AR(1) noise.
    phi_vector: array of AR(1) coefficients for each variable.
    innovation_cov_matrix: covariance matrix for the innovations.
    Returns an array of shape (n_points, n_variables).
    """
    n_variables = len(phi_vector)
    if innovation_cov_matrix.shape != (n_variables, n_variables):
        raise ValueError("Shape mismatch for innovation_cov_matrix")

    noise = np.zeros((n_points, n_variables))
    innovations = np.random.multivariate_normal(np.zeros(n_variables), innovation_cov_matrix, n_points)

    noise[0, :] = innovations[0, :]
    for t in range(1, n_points):
        noise[t, :] = phi_vector * noise[t-1, :] + innovations[t, :]
    return noise

def calculate_do_saturation_mg_l(temp_c, pressure_atm=1.0):
    """
    Calculates DO saturation in mg/L based on temperature (NumPy array input).
    """

    do_sat = 14.652 - 0.41022 * temp_c + 0.007991 * temp_c**2 - 0.000077774 * temp_c**3
    return np.maximum(do_sat * pressure_atm, 0)

def generate_storm_events(n_points, hourly_prob, min_duration_h, max_duration_h, max_intensity_factor=3):
    is_storm_active = False
    storm_duration_left = 0
    storm_intensity = 0
    is_storm_period = np.zeros(n_points, dtype=bool)
    storm_intensities = np.zeros(n_points, dtype=float)

    for i in range(n_points):
        if not is_storm_active:
            if np.random.rand() < hourly_prob:
                is_storm_active = True
                storm_duration_left = np.random.randint(min_duration_h, max_duration_h + 1)
                storm_intensity = np.random.uniform(0.5, max_intensity_factor)
        if is_storm_active:
            is_storm_period[i] = True
            storm_intensities[i] = storm_intensity
            storm_duration_left -= 1
            if storm_duration_left <= 0:
                is_storm_active = False
                storm_intensity = 0
    return is_storm_period, storm_intensities

# --- Main Data Generation ---
all_data_frames = []
date_rng = pd.date_range(start=START_DATE, end=END_DATE, freq=HOURLY_FREQ, inclusive="left")
n_hours = len(date_rng)

station_params_template = {
    "temp_mean": 12.0, "temp_seasonal_amp": 10.0, "temp_diel_amp": 2.5, "temp_diel_peak_h": 15,
    "do_base_saturation_factor": 0.95,
    "do_diel_photosynthesis_amp": 2.5, "do_diel_peak_h": 14, "do_diel_trough_h": 4,
    "do_hypoxia_prob_hourly": 0.0005, "do_hypoxia_severity_param": 1.5,
    "ph_base_mean": 7.8, "ph_diel_amp": 0.3, "ph_diel_peak_h": 15,
    "cond_base_mean": 300, "cond_seasonal_amp": 70, "cond_storm_dilution_factor": 0.7,
    "turb_base_mean": 3.0, "turb_storm_spike_factor": 50,
    "turb_lognorm_sigma_base": 0.3,
    "ar1_phi": np.array([0.8, 0.7, 0.6, 0.85, 0.5]),
    "innovation_variances": np.array([0.1**2, 0.2**2, 0.05**2, 5**2, 0.5**2]),
    "residual_correlations": {
        ("DO", "pH"): 0.4, ("Temp", "DO"): -0.3, ("Cond", "Turb"): -0.2
    },
    "storm_hourly_prob": 0.002, "storm_min_duration_h": 3, "storm_max_duration_h": 12, "storm_max_intensity": 2.0
}
variable_order = ["Temp", "DO", "pH", "Cond", "Turb"]

for station_idx in range(N_STATIONS):
    station_name = f"Station_{chr(ord('A') + station_idx)}"
    params = station_params_template.copy()
    print(f"Generating data for {station_name} ({n_hours} hourly points)...")

    is_storm, storm_intensity_ts = generate_storm_events(
        n_hours, params["storm_hourly_prob"], params["storm_min_duration_h"],
        params["storm_max_duration_h"], params["storm_max_intensity"]
    )

    temp_seasonal_np = params["temp_mean"] + seasonal_component(date_rng, params["temp_seasonal_amp"], phase_shift_days=200 - 365.25/4)
    temp_diel_np = diel_component(date_rng, params["temp_diel_amp"], peak_hour=params["temp_diel_peak_h"])
    temp_base = temp_seasonal_np + temp_diel_np 

    do_saturation_np = calculate_do_saturation_mg_l(temp_base) 
    do_base_target_np = do_saturation_np * params["do_base_saturation_factor"]
    do_bio_diel_amp_mod_np = params["do_diel_photosynthesis_amp"] * (1 + 0.3 * seasonal_component(date_rng, 1, 180 - 365.25/4))
    do_bio_diel_amp_mod_np = np.maximum(0, do_bio_diel_amp_mod_np)
    do_bio_diel_np = diel_component(date_rng, do_bio_diel_amp_mod_np, peak_hour=params["do_diel_peak_h"], trough_hour=params["do_diel_trough_h"])
    do_base = do_base_target_np + do_bio_diel_np

    ph_base_seasonal_np = params["ph_base_mean"] + seasonal_component(date_rng, 0.1, phase_shift_days=180 - 365.25/4)
    ph_change_from_do_bio_np = (do_bio_diel_np / (np.mean(do_bio_diel_amp_mod_np) + 1e-6)) * params["ph_diel_amp"] * 1.5 
    ph_base = ph_base_seasonal_np + ph_change_from_do_bio_np 

    cond_base_seasonal_val_np = params["cond_base_mean"] + seasonal_component(date_rng, params["cond_seasonal_amp"], phase_shift_days=220 - 365.25/4)
    cond_base = cond_base_seasonal_val_np.copy() 
    cond_storm_effect_np = (params["cond_storm_dilution_factor"] * storm_intensity_ts) * cond_base_seasonal_val_np
    cond_base[is_storm] -= cond_storm_effect_np[is_storm]
    cond_base = np.maximum(10, cond_base)

    turb_base_level_np = np.full(n_hours, params["turb_base_mean"])
    turb_storm_spikes_np = (params["turb_storm_spike_factor"] * storm_intensity_ts**1.5) * np.random.lognormal(0, 0.5, n_hours)
    turb_base_for_modification = turb_base_level_np.copy()
    turb_base_for_modification[is_storm] += turb_storm_spikes_np[is_storm]
    turb_base = np.maximum(0.1, turb_base_for_modification)

    n_vars = len(variable_order)
    innovation_cov = np.diag(params["innovation_variances"])
    for (var1_name, var2_name), corr_val in params["residual_correlations"].items():
        idx1, idx2 = variable_order.index(var1_name), variable_order.index(var2_name)
        std1, std2 = np.sqrt(params["innovation_variances"][idx1]), np.sqrt(params["innovation_variances"][idx2])
        cov_val = corr_val * std1 * std2
        innovation_cov[idx1, idx2] = innovation_cov[idx2, idx1] = cov_val
    try:
        np.linalg.cholesky(innovation_cov)
    except np.linalg.LinAlgError:
        print("Warning: Innovation covariance matrix not positive definite. Using diagonal.")
        innovation_cov = np.diag(params["innovation_variances"])
    residuals = generate_ar1_noise_multivariate(n_hours, params["ar1_phi"], innovation_cov)

    temp_series = temp_base + residuals[:, variable_order.index("Temp")]
    do_series = do_base + residuals[:, variable_order.index("DO")]
    ph_series = ph_base + residuals[:, variable_order.index("pH")]
    cond_series = cond_base + residuals[:, variable_order.index("Cond")]
    
    turb_base_noise_level_np = np.random.lognormal(mean=np.log(params["turb_base_mean"] * 0.2 + 1e-6), sigma=params["turb_lognorm_sigma_base"], size=n_hours)
    turb_residuals_dampened_np = residuals[:, variable_order.index("Turb")] * (1 - 0.8 * is_storm)
  
    turb_series = turb_base + turb_base_noise_level_np + turb_residuals_dampened_np
    turb_series[is_storm] = turb_base[is_storm] 

    is_hypoxia_hour = np.random.rand(n_hours) < params["do_hypoxia_prob_hourly"]
    hypoxia_magnitude_np = expon.rvs(scale=params["do_hypoxia_severity_param"], size=n_hours)
    do_series[is_hypoxia_hour] -= hypoxia_magnitude_np[is_hypoxia_hour]

    temp_series = np.clip(temp_series, -1, 35)
    do_series = np.clip(do_series, 0.05, 20)
    ph_series = np.clip(ph_series, 5.5, 9.5)
    cond_series = np.clip(cond_series, 5, 2000)
    turb_series = np.clip(turb_series, 0.1, 5000)

    df_station = pd.DataFrame({
        "Station": station_name, "Dates": date_rng,
        "Te": np.round(temp_series, 2),  
        "DO_mgL": np.round(do_series, 2),
        "pH": np.round(ph_series, 2), 
        "Conductivity_uScm": np.round(cond_series, 1),
        "Turbidity_NTU": np.round(turb_series, 1)
    }).rename(columns={"Te": "Temp_C"})

    all_data_frames.append(df_station)

final_df = pd.concat(all_data_frames)
final_df.to_csv(OUTPUT_CSV, index=False)
print(f"\nSynthetic hourly data generated and saved to {OUTPUT_CSV}")

if N_STATIONS > 0 and len(final_df) > 0:
    plot_df = final_df[final_df["Station"] == f"Station_{chr(ord('A'))}"].copy()
    plot_df_subset = plot_df.iloc[:24*7]

    if not plot_df_subset.empty:
        import matplotlib.pyplot as plt
        fig, axs = plt.subplots(5, 1, figsize=(15, 12), sharex=True)
        axs[0].plot(plot_df_subset["Dates"], plot_df_subset["Te"], label="Temp")       
        axs[0].set_ylabel("Temp (°C)")
        axs[1].plot(plot_df_subset["Dates"], plot_df_subset["DO_mgL"], label="DO")
        axs[1].set_ylabel("DO")
        axs[2].plot(plot_df_subset["Dates"], plot_df_subset["pH"], label="pH")
        axs[2].set_ylabel("pH")
        axs[3].plot(plot_df_subset["Dates"], plot_df_subset["Conductivity_uScm"], label="Conductivity")
        axs[3].set_ylabel("Conductivity")
        axs[4].plot(plot_df_subset["Dates"], plot_df_subset["Turbidity_NTU"], label="Turbidity")
        axs[4].set_ylabel("Turbidity")

        for ax in axs: ax.legend(loc='upper right'); ax.grid(True)
        fig.autofmt_xdate()
        plt.suptitle(f"Synthetic Hourly Water Quality Data (First 7 Days) - Station_A")
        plt.tight_layout(rect=[0, 0, 1, 0.96])
        plt.show()
    else:
        print("Not enough data to plot for Station_A subset.")
else:
    print("No data generated to plot.")